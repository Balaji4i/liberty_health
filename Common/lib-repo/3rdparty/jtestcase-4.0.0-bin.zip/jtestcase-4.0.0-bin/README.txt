
		 ===============================
		 = JTestCase [ release 4.0.0 ] =
		 ===============================
		 
		            Usage
		            =====

To use jtestcase include the following jars in your application classpath:

1) jtestcase_4.0.0.jar from dist directory

2) org.jicengine-2.0.0.jar, jaxen-core.jar, jaxen-jdom.jar, jdom-1.0.jar, saxpath.jar for lib directory

3) junit-3.8.1.jar (if you using jtestcase within junit) form extralib directory.


	                   Compile
	                   =======
	               
To compile the project, you can use the bundled build.xml file for ant; 
Type : " ant compile " in the root folder.

			
			Build Distribution Jar
			======================
			
To build a new distribution jar, use : "ant" or "ant dist" in the root folder.


Happy JTestCasing ! 


The JTestCase Team.

