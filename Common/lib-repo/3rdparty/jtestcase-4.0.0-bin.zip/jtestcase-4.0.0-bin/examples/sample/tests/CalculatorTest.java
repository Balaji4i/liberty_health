/* 
 * This program is licensed under Common Public License Version 0.5.
 *
 * For License Information and conditions of use, see "LICENSE" in packaged
 * 
 */
package sample.tests;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Vector;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.jtestcase.JTestCase;
import org.jtestcase.JTestCaseException;
import org.jtestcase.TestCaseInstance;

/**
 * Example for the use of JTestCase
 * 
 * @author <a href="mailto:yuqingwang_99@yahoo.com">Yuqing Wang</a>
 * @author <a href="mailto:faustothegrey@sourceforge.net">Fausto Lelli</a>
 *      
 */
public class CalculatorTest extends TestCase {

	/**
	 * JTestCase instance to be used in this example
	 */
	private JTestCase _jtestcase = null;

	/**
	 * Main method if you want to run the example from command line
	 * 
	 * @param args
	 *            command line parameters
	 */
	public static void main(String[] args) {
		junit.textui.TestRunner.run(suite());
	}

	/**
	 * Read the XML file with the test data and build the JTestCase instance
	 * 
	 * @param name
	 */
	public CalculatorTest(String name) {
		super(name);

		String dataFile = "sample/tests/test-data.xml";
		try {
			_jtestcase = new JTestCase(dataFile, "Calculator");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (JTestCaseException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Suite method that collects all test cases
	 * 
	 * @return The test suite
	 */
	public static Test suite() {
		TestSuite retval = new TestSuite();
		retval.addTest(new CalculatorTest("testCalculate"));
		return (retval);
	}

	/**
	 * Tests for the calculate method of Calculater.java This example shows how: -
	 * to extract the number of test cases from JTestCase and to build a loop
	 * over them - to extract the test data for a special test case - to use the
	 * test data in the test - to assert the test results with JTestCase methods
	 */
	public void testCalculate() {

		if (_jtestcase == null)
			fail("couldn't read xml definition file");

		final String METHOD = "calculate";
		
		Vector testCases = null;
		try {
			testCases = _jtestcase.getTestCasesInstancesInMethod(METHOD);
		} catch (JTestCaseException e) {
			e.printStackTrace();
			fail("error parsing xml file for calculate method " + METHOD);
		}
		
		// For each test case

		for (int i = 0; i < testCases.size(); i++) {

			// Retrieve name of test case

			TestCaseInstance testCase = (TestCaseInstance) testCases
					.elementAt(i);

			try {

				// Get hashed params for this test case
				
				HashMap params = testCase.getTestCaseParams();

				Integer var1Int = (Integer) params.get("var1");
				Integer var2Int = (Integer) params.get("var2");
				String opt = (String) params.get("opt");

				int var1 = var1Int.intValue();
				int var2 = var2Int.intValue();

				// All testing related to Calculate here
				Calculator calculator = new Calculator();
				int result = calculator.calculate(var1, var2, opt);

				// Asserting result
				boolean succeed = testCase.assertTestVariable("result",
						(new Integer(result)));

				assertTrue(testCase.getFailureReason(), succeed);
				
			} catch (JTestCaseException e) {
				
				// An error as occurred while processing JTestCase input
				System.err.print("Error executing test case  "
						+ testCase.getTestCaseName());
				e.printStackTrace();
				
				// Here you have a choice, 1) skip to the next test case ...
				continue;

				// Or you can fail all the test cases for this method 
				// *uncomment the following*
				/* 
				 * fail("Error in test case , failing all test cases for method " + METHOD);
				 */
			}
		}
	}
}
