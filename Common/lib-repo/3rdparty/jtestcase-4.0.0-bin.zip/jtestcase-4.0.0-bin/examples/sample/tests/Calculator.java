package sample.tests;

public class Calculator {

	public Calculator() {
		super();
	}

	public int calculate(int var1, int var2, String opt) {
		if (opt.equals("+"))
			return var1 + var2;
		if (opt.equals("-"))
			return var1 - var2;
		return 0;
	}

}
